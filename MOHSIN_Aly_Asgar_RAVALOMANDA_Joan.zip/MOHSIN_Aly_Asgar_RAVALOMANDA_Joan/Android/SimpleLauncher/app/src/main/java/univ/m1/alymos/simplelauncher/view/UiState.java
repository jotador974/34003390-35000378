package univ.m1.alymos.simplelauncher.view;



enum UiState {
    MAIN_MENU,
    GAME,
    GAME_OVER,
    SCOREBOARD,
    ATTRACT
}
