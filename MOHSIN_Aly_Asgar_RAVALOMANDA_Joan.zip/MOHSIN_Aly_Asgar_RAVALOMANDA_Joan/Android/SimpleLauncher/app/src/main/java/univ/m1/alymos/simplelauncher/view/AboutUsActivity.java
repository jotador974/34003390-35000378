package univ.m1.alymos.simplelauncher.view;

import android.app.ActionBar;
import android.app.Activity;
import android.os.Bundle;

import univ.m1.alymos.simplelauncher.R;

public class AboutUsActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about_us);

        ActionBar bar = getActionBar();
        if (bar != null) {
            bar.setDisplayHomeAsUpEnabled(true);
        }
    }
}
