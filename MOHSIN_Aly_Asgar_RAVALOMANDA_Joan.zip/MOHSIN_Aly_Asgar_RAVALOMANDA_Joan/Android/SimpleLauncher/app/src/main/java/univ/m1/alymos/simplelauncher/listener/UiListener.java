package univ.m1.alymos.simplelauncher.listener;



public interface UiListener {
    /**
     * Goes to the main menu
     */
    void onMainMenu();

    /**
     * Starts the game
     */
    void onStartGame();

    /**
     * Stops the entire game and goes into the game over callback.
     */
    void onStopGame();

    /**
     * Shows the scoreboard
     */
    void onShowScoreboard();
}
