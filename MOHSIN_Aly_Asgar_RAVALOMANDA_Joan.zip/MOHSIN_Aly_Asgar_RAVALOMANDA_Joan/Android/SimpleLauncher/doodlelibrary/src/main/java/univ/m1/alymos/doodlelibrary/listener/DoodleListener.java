package univ.m1.alymos.doodlelibrary.listener;


public interface DoodleListener {
    /**
     * Occurs when the game has ended or is game over.
     *
     * @param score The final score
     */
    void gameOver(int score);

    /**
     * Occurs when the score of the player has changed
     *
     * @param newScore The new score
     */
    void scoreChanged(int newScore);
    void updateTimer(long timeLeft);
}
