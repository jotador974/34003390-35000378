package univ.m1.alymos.doodlelibrary.graphics.animation;

import android.graphics.Bitmap;



public class AnimationFrame {
	/**
	 * The bitmap to display for this frame
	 */
	private Bitmap bitmap;

	/**
	 * The time (MILLISECONDS) this bitmap is allowed to be displayed
	 */
	private float frameTime;

	public AnimationFrame(Bitmap bitmap, float frameTime) {
		this.bitmap = bitmap;
		this.frameTime = frameTime;
	}

	public Bitmap getBitmap() {
		return bitmap;
	}

	public float getFrameTime() {
		return frameTime;
	}
}
