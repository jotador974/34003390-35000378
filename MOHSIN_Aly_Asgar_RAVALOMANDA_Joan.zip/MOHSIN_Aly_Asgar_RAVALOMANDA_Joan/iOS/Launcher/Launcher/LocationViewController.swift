//
//  LocalizeViewController.swift
//  Launcher
//
//  Created by RAVALOMANDA Joan on 09/11/2018.
//  Copyright © 2018 RAVALOMANDA Joan. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation

class LocationViewController: UIViewController, CLLocationManagerDelegate {
    
    //Map
    @IBOutlet weak var map: MKMapView!
    var locationManager = CLLocationManager()
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        map.showsUserLocation = true
        
        if CLLocationManager.locationServicesEnabled() == true
        {
            if CLLocationManager.authorizationStatus() == .restricted || CLLocationManager.authorizationStatus() == .denied || CLLocationManager.authorizationStatus() == .notDetermined {
                
                locationManager.requestWhenInUseAuthorization()
            }
            
            locationManager.desiredAccuracy = 1.0
            locationManager.delegate = self
            locationManager.startUpdatingLocation()
        }
        else
        {
            print("Veuillez activer les services de localisation ou le GPS")
        }
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations:[CLLocation]) {
        
        let region = MKCoordinateRegion(center: CLLocationCoordinate2D(latitude: locations[0].coordinate.latitude, longitude: locations[0].coordinate.longitude), span: MKCoordinateSpan(latitudeDelta: 0.002, longitudeDelta: 0.002))
        self.map.setRegion(region, animated: true)
    }
    func locationManager(_ manager: CLLocationManager, didFailWithError error:Error){
        print("Impossible d'accéder à votre position actuelle")
    }
    
}
