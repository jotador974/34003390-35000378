//
//  MusicViewController.swift
//  Launcher
//
//  Created by RAVALOMANDA Joan on 09/11/2018.
//  Copyright © 2018 RAVALOMANDA Joan. All rights reserved.
//

import UIKit
import AVFoundation

var audioPlayer = AVAudioPlayer()
var songs:[String] = []
var thisSong = 0
var audioStuffed = false // debug: si musique sur pause, si je clic sur un autre bouton ça bug, mais ce n'est plus le cas !

class FirstMusicViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet weak var myTableView: UITableView!
    
    //Fonction qui permet de compter le nombre de musique
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return songs.count
    }
    
    //Fonction qui permet de montrer ce qu'on veut diffuser
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell = UITableViewCell(style: .default, reuseIdentifier: "cell")
        cell.textLabel?.text = songs[indexPath.row]
        return cell
    }
    
    //Fonction qui permet à l'utilisateur de cliquer sur une music et de le jouer
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        do
        {
            let audioPath = Bundle.main.path(forResource: songs[indexPath.row], ofType: ".mp3")
            try audioPlayer = AVAudioPlayer(contentsOf: NSURL(fileURLWithPath: audioPath!) as URL)
            audioPlayer.play()
            thisSong = indexPath.row // prend le nombre de la musique que l'utilisateur à appuyer
            audioStuffed = true
        }
        catch
        {
            print("Error")
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        gettingSongNow()
    }
    func gettingSongNow()
    {
        let folderURL = URL(fileURLWithPath: Bundle.main.resourcePath!)
        
        do
        {
            let songPath = try FileManager.default.contentsOfDirectory(at: folderURL, includingPropertiesForKeys: nil, options: .skipsHiddenFiles)
            
            for song in songPath // tableau qui contient tout les URLs des musiques
            {
                var mySong = song.absoluteString
                
                if mySong.contains(".mp3") // savoir si c'est une musique
                {
                    let findString = mySong.components(separatedBy: "/") // Chercher le nom du mp3
                    mySong = findString[findString.count-1]
                    mySong = mySong.replacingOccurrences(of: "%20", with: " ") // Remplace les %20 par des espaces
                    mySong = mySong.replacingOccurrences(of: ".mp3", with: "") // Enlève les .mp3
                    songs.append(mySong)
                }
            }
            myTableView.reloadData()
            
        }
        catch
        {
            
        }
    }
    
}
