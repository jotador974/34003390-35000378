//
//  ViewController.swift
//  Launcher
//
//  Created by RAVALOMANDA Joan on 09/11/2018.
//  Copyright © 2018 RAVALOMANDA Joan. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


}

